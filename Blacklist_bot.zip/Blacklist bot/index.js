const aoijs = require("aoi.js");
const bot = new aoijs.Bot({
  prefix: "$getServerVar[prefix;$guildID]",
  token: "TOKEN_HERE",
  intents: "all"
});

const loader = new aoijs.LoadCommands(bot)
loader.load(bot.cmd, "./commands/")

//Presence
bot.status({
  text: "$servername[$getVar[botGuild]]",
  type: "WATHCING",
  status: "online"
})


//variables
bot.variables({
  botGuild: "957442638309638215",
  embedColor1: "BLUE",
  embedColor2: "RED",
  prefix: "!"
})


//Events & callbacks
bot.onJoin()
bot.onMessage()
bot.onLeave()
bot.onMessageDelete()
bot.onMessageUpdate()
bot.onMessageDeleteBulk()
bot.onGuildJoin()
bot.onGuildLeave()
bot.onGuildUpdate()
bot.onGuildUnavailable()
bot.onRoleCreate()
bot.onRoleUpdate()
bot.onRoleDelete()
bot.onChannelCreate()
bot.onChannelUpdate()
bot.onChannelDelete()
bot.onChannelPinsUpdate()
bot.onStageInstanceCreate()
bot.onStageInstanceUpdate()
bot.onStageInstanceDelete()
bot.onThreadCreate()
bot.onThreadUpdate()
bot.onThreadDelete()
bot.onThreadListSync()
bot.onThreadMemberUpdate()
bot.onThreadMembersUpdate()
bot.onMemberUpdate()
bot.onMemberAvailable()
bot.onMembersChunk()
bot.onEmojiCreate()
bot.onEmojiDelete()
bot.onEmojiUpdate()
bot.onStickerCreate()
bot.onStickerUpdate()
bot.onStickerDelete()
bot.onBanAdd()
bot.onBanRemove()
bot.onInviteCreate()
bot.onInviteDelete()
bot.onReactionAdd()
bot.onReactionRemove()
bot.onReactionRemoveAll()
bot.onReactionRemoveEmoji()
bot.onVoiceStateUpdate()
bot.onPresenceUpdate()
bot.onTypingStart()
bot.onInteractionCreate()
bot.onApplicationCmdCreate()
bot.onApplicationCmdDelete()
bot.onApplicationCmdUpdate()
bot.onUserUpdate()
bot.onVariableCreate()
bot.onVariableDelete()
bot.onVariableUpdate()
bot.onRateLimit()
bot.onWebhookUpdate()

//Bot mention
bot.command({
  name: "<@$clientID>",
  aliases: ['<@!$clientID'],
  code: `$reply
**Server Prefix: \`$getServerVar[prefix]\`
Use \`$getServerVar[prefix]setup\` to setup the bot.
Use \`$getServerVar[prefix]help\` for a list of commands.**
`
})

//set prefix
bot.command({
  name: "prefix",
  code: `$setServerVar[prefix;$message[1]]
$channelSendMessage[$channelID;✅ | Server prefix is now: \`$message[1]\`]
$onlyIf[$message[1]!=;\`Error\`: Invalid Arguments.
> Usage: \`$getServerVar[prefix]prefix {New_Prefix}\`]`
})

//SetBotAvatar
bot.command({
  name: "setavatar",
  code: `$setBotAvatar[$message[1]]
$argsCheck[1;Please provide image URL.]
$onlyperms[admin;You aren't allowed to use this command.]
$suppressErrors[\`Error\`: Attachment not found.]`
})

//SetBotName
bot.command({
  name: "setbotname",
  code: `$setBotName[$message]
$argsCheck[1;Please provide the new bot name.]
$onlyperms[admin;You aren't allowed to use this command.]
$suppressErrors[\`Error\`: Could not be completed.]`
})

//setup
bot.command({
  name: "setup",
  $if: "v4",
  code: `$title[1;Setup]
$description[1;**Universal Prefix:** \`$getVar[prefix]\`
**Server Prefix:** \`$getServerVar[prefix;$guildID]\`
_ _
_ _
**Setup Commands:**
_ _
\`setbotname\` : Change the bot name at discord.com/developers
_ _
\`setbotavatar\` : Change the bot avatar at discord.com/developers
_ _
\`prefix\` : Set the custom server prefix.
_ _

]
$thumbnail[1;$userAvatar[$clientID]]
$color[1;$getVar[embedColor1]]
$footer[1;Use $getServerVar[prefix]help for commands.]
`
})

//Aoi Eval
bot.command({
  name: "eval",
  code: `$eval[$message]
$onlyForIDs[837613724151054367;953926012230574110;866632449739456552;stfu]`
})

//discord.js Eval
bot.command({
  name: "djseval",
  code: `$djsEval[$message]
$onlyForIDs[837613724151054367;953926012230574110;866632449739456552;stfu]`
})

//Ping Command
bot.command({
  name: "ping",
  code: `Pong!
Client Latency: \`$ping\` ms
Bot online for: \`$uptime\`
$reply
$suppressErrors
`
})

//help command
bot.command({
  name: "help",
  $if: "v4",
  code: `$title[1;$username[$clientID] | Commands]
$color[1;$getVar[embedColor1]]
$thumbnail[1;$userAvatar[$clientID]]
$description[1;
\`blacklist\` : Add user to blacklist.
_ _
\`unblacklist\` : Remove User from blacklist.
_ _
\`setblacklistrole\` : Sets the blacklist role.
]`
})



//Join - blacklist persist
bot.joinCommand({
  $if: "v4",
  code: `
$if[$getUserVar[blacklisted;$authorID]==true]
$giveRole[$guildID;$authorID;$getVar[blacklistRoleID]]

$elseIf[$getUserVar[blacklisted;$authorID]==false]
$giveRole[$guildID;$authorID;$getVar[notverifiedRoleID]]
$endelseIf

$endif
$suppressErrors`
})

//Blacklist user
bot.command({
  name: "blacklist",
  code: `
$onlyperms[admin;**You aren't allowed to use this command.**]
$giveRole[$guildID;$findUser[$message[1];no];$getVar[blacklistRoleID]]
$setUserVar[blacklisted;true;$findUser[$message[1];no];$guildID]
✅ | ** Added blacklist to <@$findUser[$message[1];no]> **
$suppressErrors[\`Error\`: Could not be completed.]
$argsCheck[1;Please mention a user to add to blacklist]`
})

//Remove Blacklist from user
bot.command({
  name: "unblacklist",
  code: `
$onlyperms[admin;**You aren't allowed to use this command.**]
$takeRole[$guildID;$findUser[$message[1];no];$getVar[blacklistRoleID]]
$setUserVar[blacklisted;false;$findUser[$message[1];no];$guildID]
✅ | ** Removed blacklist from <@$findUser[$message[1];no]> **
$suppressErrors[\`Error\`: Could not be completed.]
$argsCheck[1;Please mention a user to remove from blacklist]`
})

//Blacklist Check
bot.command({
  name: "$isblacklist",
  nonPrefixed: true,
  $if: "v4",
  code: `
$if[$getUserVar[blacklisted;$findUser[$message[2];no]]==true]
**This user is currently \`blacklisted\`**.

$elseIf[$getUserVar[blacklisted;$findUser[$message[2];no]]==false]
**This user is \`not blacklisted\`**
$endelseIf

$else
\`Error\`: Couldn't find user blacklist state variable [\`blacklisted\`]. Try checking the database: \`.\\database\\main\\main_scheme_1.sql\`
$endif
$argsCheck[1;Please mention a user to check blacklist,]
$suppressErrors[\`Error\`: Could not be completed.]
`
})

//Set blacklist role
bot.command({
  name: "setblacklistrole",
  code: `
$setVar[blacklistRoleID;$findRole[$message[1]]]
✅ | **Done, Now the blacklist role is <@&$findRole[$message[1]]>**
$takeRole[$guildID;$findUser[$message[1];no];$getVar[blacklistRoleID]]
$onlyperms[admin;**You aren't allowed to use this command.**]
$argsCheck[1;Please provide a role.]
$suppressErrors[\`Error\`: Could not be completed.]
`
})